﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using OnlineCourseDiploma.Models;
using static OnlineCourseDiploma.Models.AdditionalManager;

namespace OnlineCourseDiploma.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public JsonResult GetCourseList()
        {
           return Json(CourseInfo.GetCourseList());
        }
        public JsonResult GetCourseInfoById(int id)
        {
            return Json(CourseInfo.GetCourseById(id));
        }
        public JsonResult GetLectureListByCourseId(int cId)
        {
            return Json(LectureInfo.GetLectureByCourse(cId));
        }
        public JsonResult GetLectureInfoById(int lId)
        {
            return Json(LectureInfo.GetLectureInfo(lId));
        }
        public JsonResult GetLabListByLectureId(int cId, int lId)
        {
            return Json(LabInfo.GetLabByCourse(cId,lId));
        }
        public JsonResult GetLabInfoById(int Lid)
        {
            return Json(LabInfo.GetLabInfoById(Lid));

        }
        public JsonResult GetQuiz()
        {
            return Json(LabInfo.GetLabInfoById(Lid));

        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
