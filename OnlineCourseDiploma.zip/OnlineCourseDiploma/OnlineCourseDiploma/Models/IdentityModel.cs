﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace OnlineCourseDiploma.Models
{
    public class IdentityModel
    {
       // public IdentityModel() { }
        public class Users
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public string ImageUrl { get; set; }
            public ICollection<UsersRoles> usersRoles { get; set; }
            public ICollection<UsersQuiz> usersQuizzes { get; set; }
            public ICollection<UsersCourse> userCourses { get; set; }
            public Users()
            {
                usersRoles = new List<UsersRoles>();
                usersQuizzes = new List<UsersQuiz>();
                userCourses = new List<UsersCourse>();
            }
            public string email { get; set; }
        }
        public class UsersCourse
        {
            public int Id { get; set; }
            public int UserId { get; set; }
            public Users users { get; set; }
            public int CourseId { get; set; }
            public Course course { get; set; }

        }
        public class Roles
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public ICollection<UsersRoles> usersRoles { get; set; }
            public Roles()
            {
                usersRoles = new List<UsersRoles>();
            }
        }
        public class UsersRoles
        {
            public int Id { get; set; }
            public int UsersId { get; set; }
            public Users users { get; set; }
            public int RolesId { get; set; }
            public Roles roles { get; set; }

        }
        public class Course
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public string description { get; set; }
            public string tutorsName { get; set; }
            //public int LectureId { get; set; }
            public ICollection<Lecture> lecture { get; set; }
            public ICollection<Quiz> quizzes { get; set; }
            public ICollection<Images> images { get; set; }
            public ICollection<UsersCourse> userCourses { get; set; }
            public ICollection<laboratory> laboratories { get; set; }

            public Course()
            {
                lecture = new List<Lecture>();
                quizzes = new List<Quiz>();
                userCourses = new List<UsersCourse>();
                images = new List<Images>();
                laboratories = new List<laboratory>();
            }

        }
        public class Lecture
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public string text { get; set; }
            public int CourseId { get; set; }
            [ForeignKey("CourseId")]
            public Course course { get; set; }
            //public int LaboratoryId { get; set; }
            public ICollection<Images> images { get; set; }
            public ICollection<laboratory> laboratories { get; set; }
            public Lecture()
            {
                laboratories = new List<laboratory>();
                images = new List<Images>();
            }
        }
        public class Images
        {
            public int Id { get; set; }
            public string Url { get; set; }
            public int? LectureId { get; set; }
            public Lecture lecture { get; set; }
            public int? CourseId { get; set; }
            public Course course { get; set; }
            public int? UserId { get; set; }
            public Users users { get; set; }
        }
        public class laboratory
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public string text { get; set; }
            public int LectureId { get; set; }
            public Lecture lecture { get; set; }
            public int CourseId { get; set; }
            public Course course { get; set; }

        }
        public class Answer
        {
            public string Id { get; set; }
            public string Text { get; set; }
            public string CorAnswer { get; set; }
            public string Answer1 { get; set; }
            public string Answer2 { get; set; }
            public string Answer3 { get; set; }
            public int QuizId { get; set; }
            [ForeignKey("QuizId")]
            public Quiz GetQuiz { get; set; }
        }
        public class Quiz
        {
            public int Id { get; set; }
            public string Title { get; set; }
            public int CourseId { get; set; }
            public Course course { get; set; }
            public ICollection<UsersQuiz> usersQuizzes { get; set; }
            public ICollection<Answer> answers { get; set; }
            public Quiz()
            {
                usersQuizzes = new List<UsersQuiz>();
                answers = new List<Answer>();

            }
        

         
        }
        public class UsersStep
        {
            public int Id { get; set; }
            public int UserId { get; set; }
            public int CourseId { get; set; }
            public int CourseSubscribe { get; set; }
            public int prevResultOfQuizInThisCourse { get; set; }
            public int newResultOfQuizInThisCourse { get; set; }
        }
        public class UsersQuiz
        {
            public int Id { get; set; }
            public int UsersId { get; set; }
            public Users users { get; set; }
            public int QuizId { get; set; }

            public Quiz quiz { get; set; }
            public string prevResult { get; set; }
            public string newResult { get; set; }
        }
  
    }
}
