﻿using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using static OnlineCourseDiploma.Models.IdentityModel;

namespace OnlineCourseDiploma.Models
{
    public class CourseContext: DbContext
    {
        public DbSet<Users> users { get; set; }
        public DbSet<UsersCourse> usersCourses { get; set; }
        public DbSet<Roles> roles { get; set; }
        public DbSet<UsersRoles> usersRoles { get; set; }
        public DbSet<Course> courses { get; set; }
        public DbSet<Lecture> lectures { get; set; }
        public DbSet<Images> images { get; set; }
        public DbSet<laboratory> laboratories { get; set; }
        public DbSet<Answer> answers { get; set; }
        public DbSet<Quiz> quizzess { get; set; }
        public DbSet<UsersStep> usersSteps { get; set; }
        public DbSet<UsersQuiz> UsersQuizzes { get; set; }
        public CourseContext()
          
        {
            Database.EnsureCreated();
        }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite(@"DataSource=app.db");
        }
        protected override void OnModelCreating(ModelBuilder modelbuilder)
        {
            foreach (var relationship in modelbuilder.Model.GetEntityTypes().SelectMany(e => e.GetForeignKeys()))
            {
                relationship.DeleteBehavior = DeleteBehavior.Restrict;
            }

            base.OnModelCreating(modelbuilder);
        }
    }
}
