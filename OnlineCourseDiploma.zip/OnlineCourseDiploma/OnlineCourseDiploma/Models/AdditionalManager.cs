﻿using System;
using System.Collections.Generic;
using System.Linq;
using static OnlineCourseDiploma.Models.AdditionalClass;

namespace OnlineCourseDiploma.Models
{
    public class AdditionalManager
    {
        public AdditionalManager()
        {
        }
        public class CourseInfo
        {
            public static CourseViewModel GetCourseList()
            {
                CourseContext context = new CourseContext();
                List<CourseViewModel.CourseInfo> courses = new List<CourseViewModel.CourseInfo>();
                //List<CourseViewModel.CourseInfo.Laborotory> laborotor = new List<CourseViewModel.CourseInfo.Laborotory>();
                //List<CourseViewModel.CourseInfo.Quiz> quizz = new List<CourseViewModel.CourseInfo.Quiz>();
                List<CourseViewModel.CourseInfo.Image> courseImg = new List<CourseViewModel.CourseInfo.Image>();


                var db = context.courses.ToList();
                foreach (var item in db)
                {
                   
                    var images = context.images.Where(i => i.CourseId == item.Id).ToList();
                    foreach (var imagesItem in images)
                    {
                        courseImg.Add(new CourseViewModel.CourseInfo.Image(){ 
                        Id = imagesItem.Id,
                        Url = imagesItem.Url
                        });
                    }
                    // var quizDb = context.quizzess.Where(q=>q.CourseId == item.Id).ToList();

                    courses.Add(new CourseViewModel.CourseInfo() { 
                    Id = item.Id,
                    Name = item.Name,
                    description = item.description,
                   
                    CourseImage = "salam"//courseImg.FirstOrDefault().Url

                    });
                }
                return new CourseViewModel()
                {
                    GetCourseInfo = courses
                };
            }
            public static CourseViewModel GetCourseById(int id)
            {
                CourseContext context = new CourseContext();
                List<CourseViewModel.CourseInfo> courses = new List<CourseViewModel.CourseInfo>();
                //List<CourseViewModel.CourseInfo.Laborotory> laborotor = new List<CourseViewModel.CourseInfo.Laborotory>();
                //List<CourseViewModel.CourseInfo.Quiz> quizz = new List<CourseViewModel.CourseInfo.Quiz>();
                List<CourseViewModel.CourseInfo.Image> courseImg = new List<CourseViewModel.CourseInfo.Image>();


                var db = context.courses.Where(c=>c.Id == id).ToList();
                foreach (var item in db)
                {

                    var images = context.images.Where(i => i.CourseId == item.Id).ToList();
                    foreach (var imagesItem in images)
                    {
                        courseImg.Add(new CourseViewModel.CourseInfo.Image()
                        {
                            Id = imagesItem.Id,
                            Url = imagesItem.Url
                        });
                    }
                    // var quizDb = context.quizzess.Where(q=>q.CourseId == item.Id).ToList();

                    courses.Add(new CourseViewModel.CourseInfo()
                    {
                        Id = item.Id,
                        Name = item.Name,
                        description = item.description,

                        CourseImage = "salam"//courseImg.FirstOrDefault().Url

                    });
                }
                return new CourseViewModel()
                {
                    GetCourseInfo = courses
                };

            }


        }
        public class Quizz
        {
            public static Quiz GetQuiz(int id)
            {
                CourseContext context = new CourseContext();
                //List<CourseViewModel.CourseInfo> courses = new List<CourseViewModel.CourseInfo>();
                //List<CourseViewModel.CourseInfo.Laborotory> laborotor = new List<CourseViewModel.CourseInfo.Laborotory>();
                List<Quiz.Quizzz> quizz = new List<Quiz.Quizzz>();
                List<Quiz.Quizzz.Answer> answerss = new List<Quiz.Quizzz.Answer>();
                //List<CourseViewModel.CourseInfo.Image> courseImg = new List<CourseViewModel.CourseInfo.Image>();
                var db = context.quizzess.Where(l => l.CourseId ==id).ToList();
                foreach (var item in db)
                {
                    var answer = context.answers.Where(a => a.QuizId == item.Id);
                    foreach (var ans in answer)
                    {
                        answerss.Add(new Quiz.Quizzz.Answer()
                        {
                            Title = ans.Text,
                            Ans_1 = ans.Answer1,
                            Ans_2 = ans.Answer2,
                            Ans_3 = ans.Answer3,
                            correctAns = ans.CorAnswer
                        });
                    }
                    /*  var images = context.images.Where(i => i.l == item.Id).ToList();
                      foreach (var imagesItem in images)
                      {
                          Lecimages.Add(new LabByCourseAndLecture.LabBCaLec.Image()
                          {
                              Id = imagesItem.Id,
                              Url = imagesItem.Url
                          });
                      }*/
                    // var quizDb = context.quizzess.Where(q=>q.CourseId == item.Id).ToList();

                    quizz.Add(new Quiz.Quizzz()
                    {
                        Id = item.Id,
                       answers =answerss
                        //images = Lecimages//courseImg.FirstOrDefault().Url

                    });
                }
                return new Quiz()
                {
                    GetQuizzzs = quizz
                };
            }
        }
        public class LectureInfo
        {
            public static LectureByCourse GetLectureByCourse(int id)
            {
                CourseContext context = new CourseContext();
                List<LectureByCourse.LBC> lBCs = new List<LectureByCourse.LBC>();
                List<LectureByCourse.LBC.Image> Lecimages = new List<LectureByCourse.LBC.Image>();
                var db = context.lectures.Where(l => l.CourseId == id).ToList();
                foreach (var item in db)
                {

                    var images = context.images.Where(i => i.LectureId == item.Id).ToList();
                    foreach (var imagesItem in images)
                    {
                        Lecimages.Add(new LectureByCourse.LBC.Image()
                        {
                            Id = imagesItem.Id,
                            Url = imagesItem.Url
                        });
                    }
                    // var quizDb = context.quizzess.Where(q=>q.CourseId == item.Id).ToList();

                    lBCs.Add(new LectureByCourse.LBC()
                    {
                        Id = item.Id,
                        CourseId = id,
                        Name = item.Name,
                        text = item.text,
                        images = Lecimages//courseImg.FirstOrDefault().Url

                    });
                }
                return new LectureByCourse()
                {
                    GetLBCs = lBCs
                };
            }
            public static LectureByCourse GetLectureInfo(int id)
            {
                CourseContext context = new CourseContext();
                List<LectureByCourse.LBC> lBCs = new List<LectureByCourse.LBC>();
                List<LectureByCourse.LBC.Image> Lecimages = new List<LectureByCourse.LBC.Image>();
                var db = context.lectures.Where(l => l.Id == id).ToList();
                foreach (var item in db)
                {

                    var images = context.images.Where(i => i.LectureId == item.Id).ToList();
                    foreach (var imagesItem in images)
                    {
                        Lecimages.Add(new LectureByCourse.LBC.Image()
                        {
                            Id = imagesItem.Id,
                            Url = imagesItem.Url
                        });
                    }
                    // var quizDb = context.quizzess.Where(q=>q.CourseId == item.Id).ToList();

                    lBCs.Add(new LectureByCourse.LBC()
                    {
                        Id = item.Id,
                        CourseId = id,
                        Name = item.Name,
                        text = item.text,
                        images = Lecimages//courseImg.FirstOrDefault().Url

                    });
                }
                return new LectureByCourse()
                {
                    GetLBCs = lBCs
                };

            }
            //public static LectureByCourse GetFull
        }
        public class LabInfo
        {
            public static LabByCourseAndLecture GetLabByCourse(int cId,int lId)
            {
                CourseContext context = new CourseContext();
                List<LabByCourseAndLecture.LabBCaLec> lBCs = new List<LabByCourseAndLecture.LabBCaLec>();
                //List<LabByCourseAndLecture.LabBCaLec.Image> Lecimages = new List<LabByCourseAndLecture.LabBCaLec.Image>();
                var db = context.laboratories.Where(l => l.CourseId == cId && l.LectureId ==lId).ToList();
                foreach (var item in db)
                {

                  /*  var images = context.images.Where(i => i.l == item.Id).ToList();
                    foreach (var imagesItem in images)
                    {
                        Lecimages.Add(new LabByCourseAndLecture.LabBCaLec.Image()
                        {
                            Id = imagesItem.Id,
                            Url = imagesItem.Url
                        });
                    }*/
                    // var quizDb = context.quizzess.Where(q=>q.CourseId == item.Id).ToList();

                    lBCs.Add(new LabByCourseAndLecture.LabBCaLec()
                    {
                        Id = item.Id,
                        Name = item.Name,
                        CourseId = item.CourseId,
                        LectureId = item.LectureId,
                        text = item.text
                        //images = Lecimages//courseImg.FirstOrDefault().Url

                    });
                }
                return new LabByCourseAndLecture()
                {
                    GetLabBCaLec = lBCs
                };
            }
            public static LabByCourseAndLecture GetLabInfoById(int id)
            {
                CourseContext context = new CourseContext();
                List<LabByCourseAndLecture.LabBCaLec> lBCs = new List<LabByCourseAndLecture.LabBCaLec>();
                //List<LabByCourseAndLecture.LabBCaLec.Image> Lecimages = new List<LabByCourseAndLecture.LabBCaLec.Image>();
                var db = context.laboratories.Where(l => l.Id == id).ToList();
                foreach (var item in db)
                {

                    //var images = context.images.Where(i => i.LectureId == item.Id).ToList();
                    //foreach (var imagesItem in images)
                    //{
                    //    Lecimages.Add(new LabByCourseAndLecture.LabBCaLec.Image()
                    //    {
                    //        Id = imagesItem.Id,
                    //        Url = imagesItem.Url
                    //    });
                    //}
                    // var quizDb = context.quizzess.Where(q=>q.CourseId == item.Id).ToList();

                    lBCs.Add(new LabByCourseAndLecture.LabBCaLec()
                    {
                        Id = item.Id,
                        Name = item.Name,
                        CourseId = item.CourseId,
                        LectureId = item.LectureId,
                        text = item.text,
                        //images = Lecimages//courseImg.FirstOrDefault().Url

                    });
                }
                return new LabByCourseAndLecture()
                {
                    GetLabBCaLec = lBCs
                };
            }
            //public static LectureByCourse GetFull
        }
        /* List<CourseViewModel.CourseInfo.Lecture> lecturee = new List<CourseViewModel.CourseInfo.Lecture>();

                    var lecDb = context.lectures.Where(s => s.CourseId == item.Id).ToList();
                    foreach (var lecItem in lecDb)
                    {
                        lecturee.Add(new CourseViewModel.CourseInfo.Lecture()
                        {
                            Id = lecItem.Id,
                            Name = lecItem.Name
                        });
                    }
                    var labDb = context.laboratories.Where(k=>k.CourseId == item.Id).ToList();
                    foreach (var labItem in labDb)
                    {
                        laborotor.Add(new CourseViewModel.CourseInfo.Laborotory(){ 
                        Id = labItem.Id,
                        Name = labItem.Name
                        });
                    }*/

    }

    public class File
    {

    }
}
