﻿using System;
using System.Collections.Generic;

namespace OnlineCourseDiploma.Models
{
    public class AdditionalClass
    {
        public AdditionalClass()
        {
        }

        public class CourseViewModel
        {
            public List<CourseInfo> GetCourseInfo { get; set; }
            public class CourseInfo {
                public int Id { get; set; }
                public string Name { get; set; }
                public string description { get; set; }
                public string tutorsName { get; set; }
                public string CourseImage { get; set; }
                public int UsersCount { get; set; }
                public List<Image> images { get; set; }

                public class Image
                {
                    public int Id { get; set; }
                    public string Url { get; set; }
                }
            }
        }
        public class LectureByCourse
        {
            public List<LBC> GetLBCs { get; set; }
            public class LBC
            {
                public int Id { get; set; }
                public string Name { get; set; }
                public int CourseId { get; set; }
                public string text { get; set; }
                public List<Image> images { get; set; }
                public class Image
                {
                    public int Id { get; set; }
                    public string Url { get; set; }
                }
            }

        }
        public class LabByCourseAndLecture
        {
            public List<LabBCaLec> GetLabBCaLec { get; set; }
            public class LabBCaLec
            {
                public int Id { get; set; }
                public string Name { get; set; }
                public int CourseId { get; set; }
                public string text { get; set; }
                public int LectureId { get; set; }
                //public List<Image> images { get; set; }
                //public class Image
                //{
                //    public int Id { get; set; }
                //    public string Url { get; set; }
                //}
            }

        }
        public class Quiz
        {
            public List<Quizzz> GetQuizzzs { get; set; }
            public class Quizzz
            {
                public int Id { get; set; }
                public List<Answer> answers { get; set; }
                public class Answer
                {
                    public string Title { get; set; }
                    public string Ans_1 { get; set; }
                    public string Ans_2 { get; set; }
                    public string Ans_3 { get; set; }

                    public string correctAns { get; set; }
                }
            }

        }
        /*    public List<UsersInCourse> usersInCourses { get; set; }
                public class UsersInCourse
                {
                    public int Id { get; set; }
                    public string Name { get; set; }
                    public string email { get; set; }

                }
                public List<Lecture> lectures { get; set; }
                public class Lecture
                {
                    public int Id { get; set; }
                    public string Name { get; set; }
                    public string imageUrl { get; set; }
                }
                public List<Laborotory> laborotories { get; set;}
                public class Laborotory
                {
                    public int Id { get; set; }
                    public string Name { get; set; }
                    public string imageUrl { get; set; }

                }
                public List<Quiz> quizzes { get; set; }
                public class Quiz
                {
                    public int Id { get; set; }
                    public string Title { get; set; }
                    public string Ans_1 { get; set; }
                    public string Ans_2 { get; set; }
                    public string Ans_3 { get; set; }

                    public string correctAns { get; set; }

                }*/

    }
 
}
